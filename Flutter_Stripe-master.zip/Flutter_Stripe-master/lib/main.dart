import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:stripe_flutter/home.dart';

void main() {
  Stripe.publishableKey =
      'pk_test_51LmBnzFGPLNyrnFGDLqaYINcpWUwqi758DF3ak36pszel0mqwGOn33tpNfIerT644ngoDbJ0egiQvlYut45ayzAk00k6xfMwcJ';
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Stripe',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
