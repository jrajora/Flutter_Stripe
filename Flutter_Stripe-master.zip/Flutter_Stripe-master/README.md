# Hi, I'm NASEER! 👋
# Flutter-Stripe

The Stripe Flutter SDK allows you to build delightful payment experiences in your native Android and iOS apps using Flutter. We provide powerful and customizable UI screens and elements that can be used out-of-the-box to collect your users' payment details.



## Authors

- [@Muhammad Naseer](https://www.github.com/naseerz)

---

## Screenshots
<p float="left">
  <img src="https://github.com/naseerx/Flutter_Stripe/blob/master/screenShots/1.png" width="300" />....
  <img src="https://github.com/naseerx/Flutter_Stripe/blob/master/screenShots/2.png" width="300" /> 
</p>


